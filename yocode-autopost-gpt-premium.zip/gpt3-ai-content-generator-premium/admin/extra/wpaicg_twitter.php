<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<a href="<?php echo esc_url(admin_url('admin.php?page=wpaicg-pricing'))?>"><img src="<?php echo esc_url(WPAICG_PLUGIN_URL)?>admin/images/twitter.png" width="70%"></a>